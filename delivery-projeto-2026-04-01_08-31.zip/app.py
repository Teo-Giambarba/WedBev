from flask import Flask

def create_app():
    app = Flask(__name__)

    from delivery.ext.config import init_app as init_config
    init_config(app)

    from delivery.ext.debugtoolbar import init_app as init_toolbar
    init_toolbar(app)

    from delivery.views import init_app as init_main
    init_main(app)

    return app