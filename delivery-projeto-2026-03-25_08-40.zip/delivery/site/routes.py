from flask import render_template
from delivery.site import bp   # ou from delivery.site import bp  (mas . é melhor)

@bp.route("/")
@bp.route("/home")
def index():
    print("Rota / (index) foi chamada!")   # deve aparecer ao acessar a URL
    return render_template("site/index.html", titulo="Home - Funcionou!")

@bp.route("/teste")
def teste():
    return "<h1>Teste OK – rota /teste funcionando</h1>"

@bp.route("/sobre")
def sobre():
    print("Rota /sobre foi chamada!")
    return render_template("site/sobre.html", titulo="Sobre Nós")

@bp.route("/contato")
def contato():
    print("Rota /contato foi chamada!")
    return render_template("site/contato.html", titulo="Fale Conosco")

@bp.route("/carrinho")
def carrinho():
    carrinho = {
       'itens' : [  
           {'id': 1, 'nome' : "Pizza Calabresa", 'preco': 49.95, 'quantidade': 1},
           {'id': 2, 'nome' : "Refrigerante 600ml", 'preco': 9.52, 'quantidade': 3},
           {'id': 3, 'nome' : "Borda Recheada", 'preco': 12.358, 'quantidade': 1},
       ]
       # 'itens': [] #~Teste Vazio
    }
    total = sum(item['preco'] * item['quantidade'] for item in carrinho['itens'])
    print("Rota /carrinho foi chamada!")
    return render_template("site/carrinho.html", carrinho=carrinho, total=total, titulo="Meus Pedidos")
